from django.shortcuts import render, get_object_or_404
from .models import Course

# Create your views here.
def index(request):
    courses = Course.objects.all()
    return render(request, 'index.html', {'cursos': courses})

def details(request, slug):
    course = get_object_or_404(Course, slug=slug)
    return render(request, 'details.html', {'course': course})
