from django.conf.urls import include, url
from simplemooc.courses import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    
    #recebe um numero por GET
    url(r'^(?P<slug>[\w_-]+)/$', views.details, name='details'),
]
